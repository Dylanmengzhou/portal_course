import tkinter as tk
import tkinter.ttk as ttk
from turtle import back, bgcolor
from xml.dom.minidom import Identified
from PIL import Image, ImageTk
from tkinter import CENTER, messagebox
import os
import excute
import pymongo
from pymongo import MongoClient
basedir = os.path.dirname(__file__)
print(basedir)

cluster = pymongo.MongoClient("mongodb+srv://dylan:DylanBee23@cluster0.a4ejgtt.mongodb.net/?retryWrites=true&w=majority")
db = cluster["user"]
collection = db["member"]

def qulified(id_num):
    res = collection.find_one({"id_num": id_num});
    if res == None:
        print("no such user")
        return -1
    elif res["time"] == 0:
        print("No time left")
        return 0
    else:
        collection.update_one({"id_num": id_num}, {"$set": {"time":res["time"]-1}})
        return 1
def get():

    global id_num, password, save_status, course_order

    id_num = usr_name_var.get()
    password = password_var.get()
    course_order = course_order_var.get()

    check = qulified(id_num)
    if check == -1:
        save_status = False
        tk.messagebox.showinfo(title='提示', message='请先注册')
    elif check == 0:
        save_status = False
        tk.messagebox.showinfo(title='提示', message='次数已用完')
    elif check==1:
        if id_num == '' or password == '':
            # if not, show a message box
            tk.messagebox.showinfo(title='提示', message='请输入用户名和密码')
        else:
            if course_order.isnumeric() or course_order == '':
                if course_order == '':
                    course_order = "default"

                else:
                    course_order = list(course_order)
                # change the button to clicked
                tk.messagebox.showinfo(title='提示', message='检查成功')
                id_entry.config(state='disabled')
                save_status = True
            else:
                course_order = "initial"
                tk.messagebox.showinfo(title='提示', message='只能输入数字来设置课程顺序，不能包含字母')


def des():
    # check the save button is clicked or not
    global id_num, password, course_order,save_status
    if save_status == False:
        tk.messagebox.showinfo(title='提示', message='请点击<检查输入>按钮')
    else:
        save_status = False
        # if yes, destroy the window
        if course_order != 'initial' and course_order != 'default':
            excute.execute(id_num, password, usr_setting=True,
                           usr_setting_course_order=course_order)
        else:
            excute.execute(id_num, password, usr_setting=False,
                           usr_setting_course_order=[])


def res():
    try:
        with open(os.path.join(basedir, "login.txt"), "x") as f:
            f.write("initial")
    except:
        pass
    with open(os.path.join(basedir, "login.txt"), "r") as f:
        txt = f.read().splitlines()
    if txt[0] == "initial":
        tk.messagebox.showinfo(title='提示', message='未保存用户名和密码，请输入用户名和密码并保存')
    else:
        global id_num, password
        id_num = txt[0]
        password = txt[1]
        id_entry.delete(0, tk.END)
        pass_entry.delete(0, tk.END)
        id_entry.insert(0, id_num)
        pass_entry.insert(0, password)


def save():
    global id_num, password, save_status

    id_num = usr_name_var.get()
    password = password_var.get()

    if id_num == '' or password == '':
        # if not, show a message box
        tk.messagebox.showinfo(title='提示', message='请输入用户名和密码')
    else:
        try:
            with open(os.path.join(basedir, "login.txt"), "x") as f:
                f.write("initial")
        except:
            pass

        with open(os.path.join(basedir, "login.txt"), "w") as f:
            f.write(id_num+"\n"+password)
        tk.messagebox.showinfo(title='提示', message='保存到本地成功')



if __name__ == "__main__":

    # 登录按钮
    id_num = 'initial'
    password = 'initial'
    course_order = 'initial'
    save_status = False
    color = "white"

    window = tk.Tk()
    window.title('抢课登陆界面')       # 设置窗口的标题
    window.geometry('500x400')     # 设置窗口的大小

    # 设置窗口的位置
    window.geometry('+500+200')
    window.resizable(False, False)


    # 画布放在window的顶部
    canvas = tk.Canvas(window, height=200, width=500, highlightthickness=0)
    # set the color of the background
    canvas.create_rectangle(-2, -2, 500, 200, fill=color,)
    # set the position of the canvas to the center of the window


    canvas.pack(side='top')


    image_file = Image.open(os.path.join(basedir, 'HYU_pic.png'))
    image_file = image_file.resize((180, 180))
    image_file = ImageTk.PhotoImage(image_file)
    image = canvas.create_image(250, 110, anchor='center', image=image_file)

    # 输入框的提示语
    tk.Label(window, text="用户名:").place(x=75, y=250, anchor='nw')
    tk.Label(window, text="密码  :").place(x=82, y=280, anchor='nw')
    tk.Label(window, text="请输入抢课顺序：").place(x=22, y=313, anchor='nw')
    tk.Label(window, text="(可选)(例子：54231)").place(x=350, y=313, anchor='nw')
    # 两个输入框
    usr_name_var = tk.StringVar()
    password_var = tk.StringVar()
    course_order_var = tk.StringVar()

    id_entry = tk.Entry(window, textvariable=usr_name_var)
    id_entry.place(x=150, y=250, anchor='nw')
    pass_entry = tk.Entry(window, textvariable=password_var, show='*')
    pass_entry.place(x=150, y=280, anchor='nw')
    tk.Entry(window, textvariable=course_order_var).place(
        x=150, y=310, anchor='nw')




    save_btn = tk.Button(window, text='检查输入', command=get, bg='white',
                    fg='black', activebackground=("#D22B2B"))
    save_btn.place(x=150, y=350)

    tk.Button(window, text="开始运行", command=des,  bg='white', fg='black',
        activebackground=("#097969")).place(x=250, y=350)

    store = tk.Button(window, text="加载账号密码", command=res,  bg='white',
                fg='black', activebackground=("#FFC300"))
    store.place(x=350, y=250, anchor='nw')

    save_info = tk.Button(window, text="保存账号密码", command=save,  bg='white',
                    fg='black', activebackground=("#0096FF"))
    save_info.place(x=350, y=280)


    window.mainloop()
